const Td = ({value}) => {
    return(
        <>
            <td>{value}</td>
        </>
    )
}

export default Td;