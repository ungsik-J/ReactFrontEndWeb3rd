
import './App.css'
import Table from './components/Table'

const App = () => {
  

  return (
    <>
      <Table/>     
    </>
  )
}

export default App

